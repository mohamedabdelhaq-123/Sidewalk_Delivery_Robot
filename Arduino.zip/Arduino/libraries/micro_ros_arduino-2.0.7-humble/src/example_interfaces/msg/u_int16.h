// generated from rosidl_generator_c/resource/idl.h.em
// with input from example_interfaces:msg/UInt16.idl
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__U_INT16_H_
#define EXAMPLE_INTERFACES__MSG__U_INT16_H_

#include "example_interfaces/msg/detail/u_int16__struct.h"
#include "example_interfaces/msg/detail/u_int16__functions.h"
#include "example_interfaces/msg/detail/u_int16__type_support.h"

#endif  // EXAMPLE_INTERFACES__MSG__U_INT16_H_
